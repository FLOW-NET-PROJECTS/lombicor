// ── Apply.jsx — multi-step applicant form ──────────────────────────────────
// NOTE: In the self-hosted version, replace base44.entities.Applicant.create()
// and base44.integrations.Core.UploadFile() with your own backend API calls.
// See README.md for backend integration guidance.

import React, { useState, useRef } from "react";
import { CheckCircle, ChevronRight } from "lucide-react";

const STEPS = ["Personal Info", "Experience", "Documents", "Review"];

function generateRef() {
  return "APP-" + Date.now().toString(36).toUpperCase().slice(-6);
}

function validateSAID(id) {
  if (!/^\d{13}$/.test(id)) return false;
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    let n = parseInt(id[i]);
    if (i % 2 === 1) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
  }
  return (10 - (sum % 10)) % 10 === parseInt(id[12]);
}

function FileUpload({ label, icon, value, onUpload, loading }) {
  const inputRef = useRef();
  return (
    <div
      className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-all"
      style={{ borderColor: value ? "#2dff7a" : "#1e2b22", background: value ? "rgba(45,255,122,0.05)" : "#111810" }}
      onClick={() => !loading && inputRef.current.click()}
    >
      <input ref={inputRef} type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden"
        onChange={e => e.target.files[0] && onUpload(e.target.files[0])} />
      {loading ? (
        <div className="flex items-center justify-center gap-2" style={{ color: "#4a6350" }}>
          <div className="w-4 h-4 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "#2dff7a", borderTopColor: "transparent" }}></div>
          <span className="text-sm">Uploading…</span>
        </div>
      ) : value ? (
        <div className="flex items-center justify-center gap-2" style={{ color: "#2dff7a" }}>
          <CheckCircle size={16} />
          <span className="text-sm font-medium">{label} uploaded</span>
        </div>
      ) : (
        <>
          <div className="text-2xl mb-1">{icon}</div>
          <div className="text-sm font-medium" style={{ color: "#d4e8d8" }}>{label}</div>
          <div className="text-xs mt-1" style={{ color: "#4a6350" }}>Click to upload · PDF/JPG/PNG · 5MB max</div>
        </>
      )}
    </div>
  );
}

export default function Apply() {
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [refId, setRefId] = useState("");
  const [errors, setErrors] = useState({});
  const [uploadLoading, setUploadLoading] = useState({});

  const [form, setForm] = useState({
    first_name: "", surname: "", id_number: "", contact_number: "",
    gender: "", race: "", address: "",
    packhouse_exp: false, forklift_licence: false,
    id_copy_url: "", proof_sars_url: "", proof_bank_url: "",
    payslip_url: "", forklift_doc_url: "",
  });

  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]: "" })); };

  function validateStep(s) {
    const errs = {};
    if (s === 0) {
      if (!form.first_name.trim()) errs.first_name = "Required";
      if (!form.surname.trim()) errs.surname = "Required";
      if (!validateSAID(form.id_number)) errs.id_number = "Enter a valid 13-digit SA ID number";
      if (!/^0\d{9}$/.test(form.contact_number)) errs.contact_number = "Enter a valid 10-digit phone number";
      if (!form.gender) errs.gender = "Required";
      if (!form.race) errs.race = "Required";
      if (!form.address.trim()) errs.address = "Required";
    }
    return errs;
  }

  function nextStep() {
    const errs = validateStep(step);
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setStep(s => s + 1);
  }

  async function handleUpload(field, file) {
    if (file.size > 5 * 1024 * 1024) { setErrors(e => ({ ...e, [field]: "File must be under 5MB" })); return; }
    setUploadLoading(u => ({ ...u, [field]: true }));
    // TODO: Replace with your own upload endpoint
    // const res = await fetch('/api/upload', { method: 'POST', body: formData });
    // const { file_url } = await res.json();
    // set(field, file_url);
    alert("Replace handleUpload() with your own API call. See README.md.");
    setUploadLoading(u => ({ ...u, [field]: false }));
  }

  async function handleSubmit() {
    setSubmitting(true);
    const ref = generateRef();
    // TODO: Replace with your own API call
    // await fetch('/api/applicants', { method: 'POST', body: JSON.stringify({ ...form, ref_id: ref, status: 'new' }) });
    alert("Replace handleSubmit() with your own API call. See README.md.");
    setRefId(ref);
    setSubmitted(true);
    setSubmitting(false);
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ background: "#080c0a" }}>
        <div className="text-center max-w-md">
          <div className="text-6xl mb-6">✅</div>
          <h1 className="text-3xl font-bold mb-3" style={{ color: "#2dff7a", fontFamily: "Syne, sans-serif" }}>Application Submitted!</h1>
          <p className="mb-6" style={{ color: "#d4e8d8" }}>Your application has been received. Keep your reference number safe.</p>
          <div className="rounded-lg p-5 mb-8" style={{ background: "#0e1410", border: "1px solid #1e2b22" }}>
            <div className="text-xs tracking-widest uppercase mb-2" style={{ color: "#4a6350" }}>Reference Number</div>
            <div className="text-2xl font-bold tracking-wider" style={{ color: "#2dff7a" }}>{refId}</div>
          </div>
          <p className="text-sm" style={{ color: "#4a6350" }}>We'll be in touch. Thank you for applying.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "#080c0a", fontFamily: "'DM Mono', monospace" }}>
      <div style={{ background: "#0e1410", borderBottom: "1px solid #1e2b22" }} className="px-6 py-4">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div>
            <div className="text-xs tracking-widest uppercase mb-1" style={{ color: "#2dff7a" }}>Recruitment Portal</div>
            <div className="text-xl font-bold" style={{ color: "#d4e8d8", fontFamily: "Syne, sans-serif" }}>Job Application</div>
          </div>
          <div className="text-right">
            <div className="text-xs mb-1" style={{ color: "#4a6350" }}>Step {step + 1} of {STEPS.length}</div>
            <div className="text-sm" style={{ color: "#2dff7a" }}>{STEPS[step]}</div>
          </div>
        </div>
        <div className="max-w-2xl mx-auto mt-4">
          <div className="h-1 rounded-full" style={{ background: "#1e2b22" }}>
            <div className="h-1 rounded-full transition-all duration-500" style={{ width: `${((step + 1) / STEPS.length) * 100}%`, background: "#2dff7a" }}></div>
          </div>
          <div className="flex justify-between mt-2">
            {STEPS.map((s, i) => (
              <div key={s} className="text-xs" style={{ color: i <= step ? "#2dff7a" : "#4a6350" }}>{s}</div>
            ))}
          </div>
        </div>
      </div>
      <div className="max-w-2xl mx-auto p-6">
        <p className="text-center text-xs mb-6 p-3 rounded" style={{ background: "#111810", border: "1px solid #2dff7a22", color: "#4a6350" }}>
          ⚠️ Self-hosted version — connect your own backend. See README.md.
        </p>
        {/* Steps omitted for brevity — see original Apply.jsx for full step UI */}
      </div>
    </div>
  );
}