// ── Admin.jsx — admin dashboard ──────────────────────────────────────────────
// NOTE: Replace all base44.entities.* and base44.auth.* calls with your own
// backend API calls. See README.md for guidance.

export default function Admin() {
  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "#080c0a" }}>
      <div className="text-center p-8 rounded-lg max-w-sm" style={{ background: "#0e1410", border: "1px solid #1e2b22" }}>
        <div className="text-4xl mb-4">🔧</div>
        <div className="text-lg font-bold mb-2" style={{ color: "#d4e8d8", fontFamily: "Syne, sans-serif" }}>Backend Required</div>
        <div className="text-sm" style={{ color: "#4a6350" }}>Connect your own backend to enable the admin dashboard. See README.md.</div>
      </div>
    </div>
  );
}